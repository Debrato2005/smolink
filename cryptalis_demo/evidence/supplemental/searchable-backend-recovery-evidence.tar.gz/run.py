from pathlib import Path
import importlib.util,os,subprocess,sys
root=Path('/workspace/cryptalis');work=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('fresh',root/'scripts/fresh_cluster_qualification.py')
fresh=importlib.util.module_from_spec(spec);spec.loader.exec_module(fresh)
source=work/'source';source.mkdir(mode=0o700,exist_ok=False)
manifest={'owner_role':'cryptalis_search_recovery_owner','runtime_role':'cryptalis_search_recovery_runtime','database':'cryptalis_search_recovery'}
cluster=None
try:
 cluster,port,password=fresh.start_cluster(source)
 credentials=fresh.provision(port,password,manifest,'cryptalis_search_recovery_plain')
 config=fresh.write_home(source,port,manifest,credentials,source_database=manifest['database'])
 environment=dict(os.environ,CRYPTALIS_TEST_CONFIG_DIR=str(config),CRYPTALIS_SQLMODEL_HTTP_SOURCE='/workspace/independent-backend-preview')
 environment.pop('PYTHONPATH',None)
 command=[sys.executable,str(root/'scripts/fresh_cluster_qualification.py'),'--workdir',str(work/'fresh'),'--sqlmodel-http','--installed-wheel','/workspace/scratch/cryptalis-package-20261101/artifacts/cryptalis-0.1.0a1-py3-none-any.whl']
 result=subprocess.run(command,cwd=root,env=environment).returncode
finally:
 if cluster is not None:fresh.stop_cluster(cluster)
raise SystemExit(result)
