import { expect, test } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

test('guest preview and account navigation have no API calls or browser errors', async ({
  page,
}) => {
  const errors: string[] = [];
  const requests: string[] = [];
  page.on('pageerror', (e) => errors.push(e.message));
  page.on('console', (m) => {
    if (m.type() === 'error') errors.push(m.text());
  });
  page.on('request', (r) => {
    if (r.url().includes('/api/v1')) requests.push(r.url());
  });
  await page.goto('/');
  await page.getByLabel('Destination URL').fill('https://example.com/reading');
  await page.getByRole('button', { name: 'Shorten URL' }).click();
  await expect(
    page.getByText('Your link is ready', { exact: true }),
  ).toBeVisible();
  await expect(page.getByLabel('Short URL', { exact: true })).toHaveValue(
    /https:\/\/smolink\.test\/[a-z0-9]+$/,
  );
  await page.getByRole('link', { name: 'Sign in', exact: true }).click();
  await expect(page.getByRole('main')).toBeFocused();
  await expect(page.getByRole('heading', { level: 1 })).toHaveText('Sign in');
  await page.reload();
  await expect(page.getByLabel('Email address')).toBeVisible();
  expect(errors).toEqual([]);
  expect(requests).toEqual([]);
  expect(
    (
      await new AxeBuilder({ page })
        .withTags(['wcag2a', 'wcag2aa', 'wcag21aa', 'wcag22aa'])
        .analyze()
    ).violations,
  ).toEqual([]);
});
for (const width of [320, 390, 768, 1024, 1440]) {
  test(`home reflows and passes axe at ${width}px`, async ({ page }) => {
    await page.setViewportSize({ width, height: 900 });
    await page.goto('/');
    expect(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth,
      ),
    ).toBe(true);
    expect(
      (
        await new AxeBuilder({ page })
          .withTags(['wcag2a', 'wcag2aa', 'wcag21aa', 'wcag22aa'])
          .analyze()
      ).violations,
    ).toEqual([]);
    await page.screenshot({
      path: `test-results/${test.info().project.name}-${width}.png`,
    });
  });
}
test('keyboard, navigation recovery, resize and reduced motion remain usable', async ({
  page,
}) => {
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await page.goto('/');
  // main.tsx renders after an async gateway import, which can follow `load`.
  await page.getByRole('link', { name: 'Skip to content' }).waitFor({
    state: 'attached',
  });
  await page.keyboard.press('Tab');
  await expect(
    page.getByRole('link', { name: 'Skip to content' }),
  ).toBeFocused();
  await page.keyboard.press('Enter');
  await expect(page.getByRole('main')).toBeFocused();
  const button = page.getByRole('button', { name: 'Shorten URL' });
  expect(
    await button.evaluate((el) => getComputedStyle(el).transitionDuration),
  ).toBe('0s');
  await button.hover();
  expect(await button.evaluate((el) => getComputedStyle(el).transform)).toBe(
    'none',
  );
  await page.getByLabel('Destination URL').fill('https://example.com/resize');
  for (const width of [390, 1440, 320]) {
    await page.setViewportSize({ width, height: 900 });
    await expect(page.getByLabel('Destination URL')).toHaveValue(
      'https://example.com/resize',
    );
    expect(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth,
      ),
    ).toBe(true);
  }
  await page.goto('/dashboard');
  await expect(page.getByRole('heading', { level: 1 })).toHaveText(
    'A home for your links.',
  );
  await page.goto('/missing');
  await expect(page.getByRole('heading', { level: 1 })).toHaveText(
    'Page not found',
  );
  await page.getByRole('link', { name: 'Back to short links' }).click();
  await expect(page.getByLabel('Destination URL')).toBeVisible();
});

test('navbar items box on hover, focus and the active route, then collapse on phones', async ({
  page,
}) => {
  const boxed = (locator: import('@playwright/test').Locator) =>
    locator.evaluate((element) => {
      const style = getComputedStyle(element);
      return {
        fill: style.backgroundColor,
        shadow: style.boxShadow,
        moved: style.transform !== 'none',
        duration: style.transitionDuration,
      };
    });
  await page.setViewportSize({ width: 1024, height: 800 });
  await page.goto('/');
  const navigation = page.getByRole('navigation', { name: 'Main navigation' });
  const item = navigation.getByRole('link', { name: 'Questions' });
  const rest = await boxed(item);
  expect(rest.shadow).toBe('none');
  expect(rest.moved).toBe(false);
  // Every transition is quick and tactile: between 120 and 180 ms.
  for (const part of rest.duration.split(','))
    expect(parseFloat(part) * 1000).toBeGreaterThanOrEqual(120);
  for (const part of rest.duration.split(','))
    expect(parseFloat(part) * 1000).toBeLessThanOrEqual(180);
  await item.hover();
  await expect
    .poll(async () => (await boxed(item)).shadow)
    .toBe('rgb(0, 0, 0) 4px 4px 0px 0px');
  expect((await boxed(item)).moved).toBe(true);
  await page.mouse.move(0, 700);
  await item.focus();
  await expect
    .poll(async () => (await boxed(item)).shadow)
    .toContain('4px 4px 0px 0px');
  await page.goto('/dashboard');
  const active = navigation.getByRole('link', { name: 'Workspace' });
  await expect(active).toHaveAttribute('aria-current', 'page');
  await expect
    .poll(async () => (await boxed(active)).shadow)
    .toContain('4px 4px 0px 0px');
  await page.emulateMedia({ reducedMotion: 'reduce' });
  expect((await boxed(active)).moved).toBe(false);
  for (const width of [768, 390]) {
    await page.setViewportSize({ width, height: 800 });
    expect(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth,
      ),
    ).toBe(true);
    await expect(navigation).toBeVisible({ visible: width >= 768 });
    await expect(
      page.getByRole('button', { name: 'Open navigation' }),
    ).toBeVisible({ visible: width < 768 });
  }
});
