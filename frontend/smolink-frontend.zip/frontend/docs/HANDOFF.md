# Frontend handoff

**Owner:** Current frontend continuation checkpoint

Checkpoint: October 7, 2026. All receipts below come from this session's final source state.

## Current objective

The user rejected the previous look and asked for a rebuild from three references (neobrutalism.dev, neubrutalism.com, and the Medium neobrutalism guide), a Continue with Google option, and removal of every demo, sample, and synthetic mention. This session delivered all three. [DESIGN_SYSTEM.md](DESIGN_SYSTEM.md) owns the rules.

**The product is not release-ready.** Live accounts, Google OIDC, QR, redirects, owner management, and analytics depend on the backend blockers below. Only Chromium ran.

User constraints: write only inside `frontend/`; never run `git add`, `commit`, or `push`; preserve backend contracts; never fake backend capability; decide components from screenshots; apply Ponytail.

## What changed in this session

| Area                    | Change                                                                                                                                                                                                                                                                                                                             |
| ----------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Look                    | Sky-blue page ground (`--sky-surface`) under the SVG grid. Boxed yellow logo mark. Boxed Sign in and ink Sign up and My links buttons. Centered hero with "Smol" in outlined yellow. Static yellow highlights strip. Four solid color feature cards. Three numbered step cards. Boxed FAQ. Inputs lift with a hard shadow on focus |
| Decisions by screenshot | A/B captures compared green, yellow, and coral for the hero word (yellow won on contrast), and the shortener with and without the length ruler and title strip (both removed)                                                                                                                                                      |
| Ponytail                | Deleted `LengthRuler`, the mode banner, the anatomy specimen, the ledger, sidebar, and table notes, and one FAQ entry. CSS fell from 34.36 kB to 32.88 kB                                                                                                                                                                          |
| Google                  | Continue with Google on sign-in and registration, with Google's multicolor G. Development data resolves a `google` account action. Production disables it under "Accounts are coming soon"                                                                                                                                         |
| Copy                    | No demo, sample, synthetic, or fixture wording in product copy. Missing backend features say coming soon. Fixture URLs use reserved `smolink.test`. Development-only Developer tools, Use test account, and Use test link are gated on `import.meta.env.DEV`                                                                       |
| Tests                   | New Google test. Production test asserts no banned wording and a disabled Google button. Copy-dependent assertions updated                                                                                                                                                                                                         |

## Verified checks

| Check                                                                     | Observed result                                                                                                                               |
| ------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------- |
| `npm run typecheck`, `lint`, `format:check`                               | Passed                                                                                                                                        |
| `npm test`                                                                | 9 passed                                                                                                                                      |
| `npm run test:e2e -- --project=chromium`                                  | 21 passed. Substitute Chromium 153.0.8010.0 through `SMOLINK_CHROMIUM_PATH`                                                                   |
| `npm run build`                                                           | Passed. JavaScript 367.85 kB (gzip 116.30 kB). CSS 32.88 kB (gzip 6.93 kB)                                                                    |
| Production bundle scan                                                    | 0 matches for `smolink.test`, `test-token`, `fixtureLinks`                                                                                    |
| Production page-text scan (`/`, `/login`, `/dashboard` at 1440 and 390px) | 0 banned words. "Coming soon" only on backend-missing features                                                                                |
| `SMOLINK_E2E_TARGET=production npm run test:e2e -- --project=chromium`    | 4 passed                                                                                                                                      |
| Impeccable detector                                                       | 0 findings                                                                                                                                    |
| Visual review                                                             | Captures at 1440, 1024, 768, and 390px of home, navbar states, sign-in (development and production), dashboard, mobile menu. No page overflow |

Screenshots and the round log are in the ignored `.local/shots/` folder. Not run: Firefox, WebKit, physical devices, screen readers, and any real-stack journey.

## Blockers and cross-boundary dependencies

### ENV-02: Browser runtimes

This host cannot download Playwright's pinned runtimes. Chromium ran through a substitute binary. Firefox and WebKit did not run. WebKit also needs `libevent-2.1-7t64` and `libgstreamer-plugins-bad1.0-0` on a provisioned host.

### CB-01: Lossless public ID transport

Owner: backend API/schema owners. Relevant files: `backend/app/schemas/url.py` and `backend/app/schemas/auth.py`. Current public IDs are JSON numbers. Required change: specify and implement lossless public IDs, preferably decimal strings, with matching tests and examples. JavaScript cannot restore precision after parsing an unsafe number. Frontend can preview public creation results without an ID, but live owner/account operations need the resolved transport contract. Independent fixture UI remains possible.

### CB-02: Browser session delivery and storage

Owner: backend authentication and security. Relevant files: `backend/app/api/v1/endpoints/auth.py`, `backend/app/schemas/auth.py`, `backend/app/services/auth_service.py`, and `docs/superpowers/specs/2026-08-01-authentication-authorization-design.md`. Current login/refresh return Bearer token JSON; no approved browser cookie/session delivery contract exists. Required decision: compare a same-origin server-managed session with in-memory browser credentials, including expiry, reload, CSRF where applicable, logout, and error handling. Frontend must not silently select persistent refresh-token storage. This blocks live session integration, not account form construction.

### CB-03: Rotation and browser concurrency

Owner: backend authentication with frontend session owner. Relevant files: `backend/app/services/auth_service.py` and `backend/app/repositories/auth_repository.py`. Current refresh rotation is single-use and replay revokes the token family. Required decision: define single-flight refresh and cross-tab ownership/binding before live integration. Multiple browser rotations can invalidate a legitimate session. Frontend cannot repair a server-revoked family or safely replay an uncertain mutation. Logout currently revokes refresh credentials while a valid access token can remain usable. This blocks live session integration.

### CB-04: Missing product endpoints

Owner: backend URL and analytics services. Relevant files: `backend/app/main.py`, `backend/app/api/v1/router.py`, and `backend/app/api/v1/endpoints/urls.py`. Current implementation lacks owner listing/update/delete, public redirect, QR, and analytics endpoints. Required change: implement explicit contracts, authorization, errors, and tests before live integration. Fixtures may support independent UI work, but cannot prove persistence, ownership enforcement, redirects, or reports.

### CB-05: Google OIDC and backend test collection

Owner: backend authentication. Relevant files: `backend/app/utils/oidc.py`, `backend/tests/test_oidc.py`, and mounted auth routes. Google start/callback routes are absent. The test module imports missing `create_pkce_challenge`; this is source-confirmed, not a fresh full-suite result. Required change: finish PKCE, browser binding, callback delivery, session handoff, and tests. Frontend cannot safely invent those security contracts. This blocks Google integration and an unconditional backend-suite claim; local fixture work remains independent.

### CB-06: Production origins and serving

Owner: deployment/infrastructure and backend. Relevant files: `backend/app/main.py`, `backend/.env.example`, and `docs/development.md`. Current backend has no CORS or SPA-serving policy. Required decision: establish TLS, production origins, API proxying or CORS, SPA deep-link fallback, security headers, and email public origin. A Vite development proxy is not production evidence. This blocks deployment integration.

### CB-07: Public short-code route precedence

Owner: backend URL service and deployment. Relevant files: `backend/app/utils/aliases.py`, `backend/app/services/url_service.py`, and `backend/app/main.py`. Current reservations do not cover every planned frontend path. Required decision: separate SPA/API paths from public codes and test collisions before publishing redirects. Frontend routing cannot enforce server-side uniqueness or request precedence. This blocks reliable deployed route integration.

### CB-08: Proxy identity and Snowflake generation

Owner: backend runtime/deployment. Relevant files: `backend/app/api/v1/dependencies/rate_limit.py`, `backend/app/utils/snowflake.py`, and the auth/URL endpoint modules. Current request identity uses the client host; trusted-proxy behavior is unresolved. Separate auth/URL generators use the same worker configuration, and timestamp bounds need backend review. Required change: define trusted proxy handling and verify generator identity/range guarantees. Frontend cannot repair rate-limit identity or database identifiers. These are backend/release dependencies, not reasons to stop fixture UI.

### CB-09: Root documentation and graph drift

Owner: repository documentation/tooling. Relevant files: root `README.md`, `docs/ENGINEERING_PLAYBOOK.md`, `docs/frontend-design-system.md`, `docs/backend-build-checklist.md`, `docs/codebase-walkthrough.md`, `docs/AGENT_GUIDE.md`, and `graphify-out/`. Root guidance still describes planned frontend work and older design ownership. Focused Graphify queries worked but warned about legacy node IDs. Required separately authorized maintenance: reconcile root guidance and refresh the graph after this frontend work. This task must not write those paths. Current source and frontend owners govern the implemented foundation within this scope.

### CB-10: Email delivery recovery contract

Owner: backend authentication/email services. Relevant files: `backend/app/api/v1/endpoints/auth.py`, `backend/app/services/email_service.py`, and `backend/app/services/auth_service.py`. Registration can commit before email delivery fails. Forgot-password and resend return empty 202 acceptance without guaranteeing delivery. Required follow-up: define provider-outage and resend recovery behavior before live forms promise an outcome. Frontend cannot undo a committed account or infer delivery from acceptance. This affects live recovery integration; form and fixture work can proceed.

### CB-09 note: root design reconciliation

`--sky-surface` is a frontend token added at the user's request. Root `docs/frontend-design-system.md` does not list it. Reconcile the root file under separate authorization. Root `graphify-out/` is absent from this checkout.

## Exact next task

**Run the fixture and production suites in Firefox and WebKit** on a host with the pinned runtimes:

```bash
npx playwright install chromium firefox webkit
npm run test:e2e -- --project=firefox --project=webkit
npm run build
SMOLINK_E2E_TARGET=production npm run test:e2e -- --project=firefox --project=webkit
```

Watch `-webkit-text-stroke` on the hero word, `cqi` sizing in the ticket, and the `clip-path` notches. Then start the live guest journey for FE-007 with `npm run dev:live`.

## Scope protections

All changes are inside `frontend/`. No commit, push, reset, stash, clean, or worktree operation occurred, and the Git index is unchanged. `.impeccable/` holds the updated direction contract; it is development-only and excluded from Prettier. Preserve `frontend/.agents/skills/` and `skills-lock.json`.
